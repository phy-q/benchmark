package dl.utils;

import java.util.ArrayList;
import java.util.List;

public class TrajectoryFeatureTransformer {
	double buildingUtil;
	double roundUtil;
	double pigUtil;

	public static List<Double> transformDLTrajIntoVec(HeartyTrajectory traj) {

		return new ArrayList<Double>();
	}
}
