Source folder for the [GitHub Pages](https://pages.github.com) of AI-AngryBird-Hearty
